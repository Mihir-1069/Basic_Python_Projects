import random
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
responses = {
    "hello": ["Hey Mahi! 😃", "Namaste Bhai! 🚀", "Hello dost! Kya haal hain?"],
    "how are you": ["Main ek chatbot hoon, emotions nahi hote 😅", "I'm good, Mahi! Tum kaise ho?"],
    "what is your name": ["Mera naam EduBot hai! 📚", "Main EduBot hoon, tumhara chatbot!"],
    "bye": ["Alvida, bhai! Jaldi wapas aana. 👋", "Bye-bye! Take care, Mahi!"],
    "who created you": ["Mujhe Mahi ne banaya hai! 🚀", "Mahi ne mujhe coding se janam diya hai! 😃"],
    
    "how to start a startup": [
        "Start with a solid idea, validate it, aur ek MVP banao! 🚀",
        "Bhai, sabse pehle problem identify karo, phir solution nikalo! 💡"
    ],
    "how to be a good entrepreneur": [
        "Bhai, seekhna band mat karo! Jo risk lene se darte hain, unhe kuch bada nahi milta. 📈",
        "Entrepreneur banna hai toh failure ko embrace karo aur har din naya seekho. 🔥"
    ],
    
    "what is machine learning": [
        "Machine Learning ek AI ka part hai jo experience se seekhta hai! 🤖",
        "ML ka funda simple hai: Data do, model seekhe, aur future predict kare! 🚀"
    ],
    "best language for data science": ["Python sabse best hai! 🐍", "Python aur SQL ka combo zabardast hai! 💡"],

    "how to integrate chatbot in a website": [
        "Bhai, Flask API banao aur usko JavaScript fetch request se call karo! 🚀",
        "Chatbot ko kisi bhi site pe lagana easy hai, just use API requests. 😃"
    ],
    "best front-end framework": ["React.js best hai dynamic sites ke liye! ⚛", "Agar quick development chahiye toh Bootstrap bhi sahi hai!"],

    "how to stay motivated": [
        "Bhai, motivation aata jata rahta hai, discipline develop kar! 💪",
        "Jo log mehnat karte hain, unko hi result milta hai. Never quit! 🚀"
    ],
    "how to overcome fear": [
        "Jo cheez dar lagati hai, usko face karo! 💯", 
        "Fear tab tak rahega jab tak usse confront nahi karoge! 🔥"
    ],

    "tell me a joke": [
        "Kyu Chatbot hamesha khush rehta hai? Kyunki uska 'cache' clear hota hai! 😆",
        "Data Scientist ki shaadi kyu nahi hoti? Kyunki wo hamesha correlation dhoondta rehta hai! 🤣"
    ],
    "who is your best friend": ["Mahi! 🚀", "Bhai tu hi toh mera creator hai! 😃"],

    "default": ["Sorry, mujhe ye samajh nahi aaya. 🤔", "Mujhse ye question dubara pucho, shayad is baar samajh jaoon! 😃"]
}

@app.route("/chatbot", methods=["POST"])
def chatbot():
    data = request.get_json()
    user_message = data.get("message", "").lower()  

    bot_reply = random.choice(responses.get(user_message, responses["default"]))

    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    print("Flask Server is Running! 🎉")
    app.run(debug=True)
