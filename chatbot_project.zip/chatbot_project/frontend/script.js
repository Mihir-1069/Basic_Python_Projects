function sendMessage() {
    let userInput = document.getElementById("user-input").value;
    let chatBox = document.getElementById("chat-box");

    if (userInput.trim() === "") return; // Empty message allow mat kar

    // User Message Show Kare
    let userMessage = document.createElement("div");
    userMessage.className = "message user-message";
    userMessage.innerText = "You: " + userInput;
    chatBox.appendChild(userMessage);

    // Flask API Call (POST Request)
    fetch("http://127.0.0.1:5000/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userInput }) 
    })
    .then(response => response.json())
    .then(data => {
        // Bot Message Show Kare
        let botMessage = document.createElement("div");
        botMessage.className = "message bot-message";
        botMessage.innerText = "Bot: " + data.reply;
        chatBox.appendChild(botMessage);
        
        // Scroll to Bottom
        chatBox.scrollTop = chatBox.scrollHeight;

        // Input Clear Karna
        document.getElementById("user-input").value = ""; 
    })
    .catch(error => console.error("Error:", error));
}
